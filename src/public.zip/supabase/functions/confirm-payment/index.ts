
import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@14.21.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { session_id } = await req.json();
    
    if (!session_id) {
      throw new Error("Session ID é obrigatório");
    }

    // Inicializar Stripe
    const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY") || "", {
      apiVersion: "2023-10-16",
    });

    // Buscar sessão do Stripe
    const session = await stripe.checkout.sessions.retrieve(session_id);

    if (session.payment_status !== 'paid') {
      throw new Error("Pagamento não foi confirmado");
    }

    // Cliente Supabase com service role para bypass RLS
    const supabaseService = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { persistSession: false } }
    );

    const metadata = session.metadata!;
    const numeros = JSON.parse(metadata.numeros);
    const valorPago = session.amount_total! / 100; // Converter de centavos para reais

    // Verificar se o pagamento já foi processado
    const { data: existingTransaction } = await supabaseService
      .from('transactions')
      .select('id, status, confirmacao_enviada')
      .eq('stripe_session_id', session_id)
      .single();

    if (existingTransaction) {
      if (existingTransaction.status === 'pago' && existingTransaction.confirmacao_enviada) {
        return new Response(JSON.stringify({ 
          success: true, 
          message: "Pagamento já processado",
          purchase: {
            numeros,
            valor_pago: valorPago,
            metodo_pagamento: metadata.metodo_pagamento,
          }
        }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // Usar transação atômica para evitar processamento duplo
      const { error: updateError } = await supabaseService
        .from('transactions')
        .update({
          status: 'pago',
          data_pagamento: new Date().toISOString(),
          confirmacao_enviada: true,
          data_confirmacao: new Date().toISOString(),
          updated_at: new Date().toISOString()
        })
        .eq('id', existingTransaction.id)
        .eq('confirmacao_enviada', false); // Condição para evitar dupla atualização

      if (updateError) {
        console.error("Erro ao atualizar transação:", updateError);
        throw new Error("Erro ao confirmar pagamento");
      }

      // Finalizar venda dos números
      const { error: saleError } = await supabaseService.rpc('finalize_sale', {
        _user_id: metadata.user_id,
        _numeros: numeros,
        _transaction_id: existingTransaction.id
      });

      if (saleError) {
        console.error("Erro ao finalizar venda:", saleError);
        throw new Error("Erro ao confirmar números vendidos");
      }

      // Log do pagamento processado
      await supabaseService
        .from('payment_logs')
        .insert({
          payment_id: session_id,
          transaction_id: existingTransaction.id,
          payload_raw: session,
          fonte: 'stripe',
          processado: true,
        });

      console.log("Pagamento confirmado para session:", session_id);
      console.log("Números vendidos:", numeros);

      return new Response(JSON.stringify({ 
        success: true,
        purchase: {
          numeros,
          valor_pago: valorPago,
          metodo_pagamento: metadata.metodo_pagamento,
        }
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    } else {
      // Criar nova transação se não existir
      const { data: newTransaction, error: insertError } = await supabaseService
        .from('transactions')
        .insert({
          user_id: metadata.user_id,
          stripe_session_id: session_id,
          payment_id: session_id,
          numeros_comprados: numeros,
          valor_total: valorPago,
          metodo_pagamento: metadata.metodo_pagamento,
          status: 'pago',
          nome: metadata.nome,
          email: metadata.email,
          telefone: metadata.telefone || null,
          data_pagamento: new Date().toISOString(),
          confirmacao_enviada: true,
          data_confirmacao: new Date().toISOString(),
        })
        .select('id')
        .single();

      if (insertError) {
        console.error("Erro ao criar transação:", insertError);
        throw new Error("Erro ao registrar pagamento");
      }

      // Finalizar venda dos números
      const { error: saleError } = await supabaseService.rpc('finalize_sale', {
        _user_id: metadata.user_id,
        _numeros: numeros,
        _transaction_id: newTransaction.id
      });

      if (saleError) {
        console.error("Erro ao finalizar venda:", saleError);
        throw new Error("Erro ao confirmar números vendidos");
      }

      // Log do pagamento processado
      await supabaseService
        .from('payment_logs')
        .insert({
          payment_id: session_id,
          transaction_id: newTransaction.id,
          payload_raw: session,
          fonte: 'stripe',
          processado: true,
        });

      console.log("Novo pagamento confirmado para session:", session_id);
      console.log("Números vendidos:", numeros);

      return new Response(JSON.stringify({ 
        success: true,
        purchase: {
          numeros,
          valor_pago: valorPago,
          metodo_pagamento: metadata.metodo_pagamento,
        }
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

  } catch (error) {
    console.error("Erro ao confirmar pagamento:", error);
    
    // Log do erro
    if (Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")) {
      try {
        const supabaseService = createClient(
          Deno.env.get("SUPABASE_URL") ?? "",
          Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
          { auth: { persistSession: false } }
        );

        await supabaseService
          .from('payment_logs')
          .insert({
            payment_id: req.body?.session_id || 'unknown',
            payload_raw: { error: error.message },
            fonte: 'stripe',
            processado: false,
            erro: error.message,
          });
      } catch (logError) {
        console.error("Erro ao registrar log:", logError);
      }
    }

    return new Response(JSON.stringify({ 
      error: error.message 
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});
